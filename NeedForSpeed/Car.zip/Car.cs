﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class Car : Vehicle
    {
        public Car(int horsePower, double fuel) : base(horsePower, fuel)
        {
            base.DefaultFuelConsumption = 3;
        }

        public override double FuelConsumption
        {
            get
            {
                return base.DefaultFuelConsumption;
            }
            set
            {
                this.DefaultFuelConsumption = value;
            }
        }

        public override void Drive(double kilometers)
        {
            double fuel = kilometers * this.FuelConsumption;
            base.Fuel -= fuel;
        }
    }
}
