﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    class MuseElf : Elf
    {
        public MuseElf(string name, int level) : base(name, level)
        {

        }
    }
}
