﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Hero hero = new Knight("gofo" ,45);

            System.Console.WriteLine(hero);
        }
    }
}